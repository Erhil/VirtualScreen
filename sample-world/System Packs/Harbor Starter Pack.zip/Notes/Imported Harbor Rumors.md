# Imported Harbor Rumors

- The lantern inspector changes passwords after the third bell.
- A blue crate marks safe passage under the old pier.
- Ask Mara Tideglass about the smuggler tide.

Imported pack search phrase: silver gull lantern.
