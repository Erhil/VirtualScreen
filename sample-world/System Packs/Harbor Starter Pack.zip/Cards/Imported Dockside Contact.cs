{
  "kind": "npc",
  "title": "Imported Dockside Contact",
  "tags": [
    "imported",
    "harbor"
  ],
  "sections": [
    {
      "title": "Profile",
      "layout": "grid",
      "fields": {
        "Name": {
          "type": "text",
          "value": "Mara Tideglass"
        },
        "Role": {
          "type": "text",
          "value": "Dockside guide"
        },
        "Trust": {
          "type": "number",
          "value": 2
        },
        "Knows Secret": {
          "type": "boolean",
          "value": true
        }
      }
    },
    {
      "title": "Hooks",
      "fields": {
        "Lead": {
          "type": "long_text",
          "value": "Mara knows which bell marks the smuggler tide."
        },
        "Link": {
          "type": "world_link",
          "value": "Notes/Imported Harbor Rumors.md"
        }
      }
    }
  ]
}
